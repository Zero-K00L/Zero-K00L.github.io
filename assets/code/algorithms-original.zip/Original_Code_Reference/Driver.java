import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
    // Scanner object for reading user input
    public static Scanner scanner = new Scanner(System.in);

    // List to store Dog objects
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    // List to store Monkey objects
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();
    
    // List of monkey species that are eligible for training
    private static final ArrayList<String> validMonkeySpecies = new ArrayList<>();
    static {
        validMonkeySpecies.add("Capuchin");
        validMonkeySpecies.add("Guenon");
        validMonkeySpecies.add("Macaque");
        validMonkeySpecies.add("Marmoset");
        validMonkeySpecies.add("Squirrel monkey");
        validMonkeySpecies.add("Tamarin");
    }
    
    // List of valid training statuses 
    private static final ArrayList<String> validTrainingStatuses = new ArrayList<>();
    static {
        validTrainingStatuses.add("intake");
        validTrainingStatuses.add("Phase I");
        validTrainingStatuses.add("Phase II");
        validTrainingStatuses.add("Phase III");
        validTrainingStatuses.add("Phase IV");
        validTrainingStatuses.add("Phase V");
        validTrainingStatuses.add("in service");
    }

    public static void main(String[] args) {
   	  // Initialize lists to use with sample data
        initializeDogList();
        initializeMonkeyList();

        // Main loop to display menu and process user inputs
        while (true) {
      	   // Display the menu options to the user
            displayMenu();
            String userInput = scanner.nextLine();

            // Process user input based on menu selection
            switch (userInput) {
                case "1":
                    intakeNewDog(scanner);
                    break;
                case "2":
                    intakeNewMonkey(scanner);
                    break;
                case "3":
                    reserveAnimal(scanner);
                    break;
                case "4":
                    printAnimals("dog");
                    break;
                case "5":
                    printAnimals("monkey");
                    break;
                case "6":
                    printAnimals("available");
                    break;
                case "q":
                    System.out.println("Exiting the application.");
                    // Close the scanner when the application is closed to free resources
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }

    // Initialize the Dog list
    public static void initializeDogList() {
   	  // Adds dogs to a list for testing
      /*Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", 
      		               "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", 
      		               "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", 
      		               "in service", false, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3); */
    }
    
    
    // Initialize the monkey list
    public static void initializeMonkeyList() {
   	  // Adds monkeys to a list for testing
      /*Monkey monkey1 = new Monkey("George", "Male", "5", "15.5", "06-01-2020", "Brazil", 
      		                        "in service", false, "United States", "Capuchin", 20.5, 30.5, 35.0);
        Monkey monkey2 = new Monkey("Lola", "Female", "3", "12.3", "04-15-2019", "India", 
      		                        "in service", false, "India", "Marmoset", 18.5, 28.2, 30.0);
        Monkey monkey3 = new Monkey("Kong", "Male", "10", "30.5", "04-07-1933", "United States", 
      		                        "in service", true, "United States", "Capuchin", 30.5, 100, 50.0);
        
        monkeyList.add(monkey1);
        monkeyList.add(monkey2);
        monkeyList.add(monkey3); */
    }
    

    // Method to intake a new dog
    public static void intakeNewDog(Scanner scanner) {
   	  // Prompt user for dog's name and check if it already exists
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        for (Dog dog : dogList) {
            if (dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return;
            }
        }

        // Gather the rest of the information for the new dog.
        // Gather and validate the dog's breed
        String breed;
        while (true) {
      	  // Prompt the user for the dog's breed
           System.out.println("What is the dog's breed?");
           breed = scanner.nextLine();
           // Validate that the breed is a non-empty string containing only alphabetic characters
           if (breed.matches("[a-zA-Z ]+")) {
         	  break;  // Exit loop if the breed is valid
           }
           else {
         	  // Print error message if breed is an empty string or contains any non letters
         	  System.out.println("Invalid input. Please enter a breed that contains only letters.");
           }
        }
        
        // Validate the dog's gender input
        String gender;
        while (true) {
      	  // Prompt the user for the dog's gender
           System.out.println("What is the dog's gender?");
           gender = scanner.nextLine();
           // Validate that the input is a string that is either 'male' or 'female'
           if (gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female")) 
         	  break;  // Exit loop if the gender input is valid
           // Error message if something other than 'male' or 'female' is entered
           System.out.println("Invalid input. Please enter 'male' or 'female'.");
        }

        // Validate the dog's age input
        String age;
        while (true) {
      	  // Prompt the user for the dog's age
           System.out.println("What is the dog's age?");
           age = scanner.nextLine();
           // Check if the age input contains only numbers
           if (age.matches("\\d+")) {
         	  // Convert age input into an integer for comparison
         	  int dogAge = Integer.parseInt(age);
         	  // Check to see if dog's age input is within a realistic range
         	  if (dogAge > 0 && dogAge < 30) {
         		  break;
         	  }
         	  else {
         		  // Error message if the input for the dog's age is to low or too high
         		  System.out.println("Invalid age. Please enter a realistic age between 1-30 years");
         	  }
           }
           else {
         	  // Error message if the age input is not a valid integer
         	  System.out.println("Invalid input. Please enter a valid integer for age.");
           }
        }

        // Validation for the dog's weight
        String weight;
        while (true) {
      	  // Prompt the user for the dog's weight
           System.out.println("What is the dog's weight?");
           weight = scanner.nextLine();
           // Check if the dog's weight is valid integer or double
           if (weight.matches("\\d+(\\.\\d+)?")) 
         	  break;  // Exit the loop if a valid weight is entered
           // Error message printed when an invalid dog weight is entered
           System.out.println("Invalid input. Please enter a valid number for the dog's weight.");
        }

        // Validation for the dog's acquisition date
        String acquisitionDate;
        int dogAge = 0;
        while(true) {
      	  // Prompt user for the acquisition date
           System.out.println("What is the dog's acquisition date? Enter in format MM-DD-YYYY.");
           // Convert date from string to an integer for use in isValidAcquisitionDate method
           dogAge = Integer.parseInt(age);
           acquisitionDate = scanner.nextLine();
           
           if (RescueAnimal.isValidAcquisitionDate(acquisitionDate, dogAge)) {
         	  break;  // Exit loop if the entered acquisition date is valid
           }
           else {
         	  // Error message printed when an invalid dog acquisition date is entered
         	  System.out.println("Invalid date. Please enter a valid acquisition date that matches "
         	  		              + "the format MM-DD-YYYY and is feasible given the dog's age.");
           }
        }
       
        // Validation for the dog's acquisition country
        String acquisitionCountry;
        while (true) {
      	  // Prompt user for the dog's acquisition country
           System.out.println("What is the dog's acquisition country?");
           acquisitionCountry = scanner.nextLine();
           // Check if acquisition country input is not empty and contains only letters
           if (!acquisitionCountry.isEmpty() && acquisitionCountry.matches("[a-zA-Z\\s]+")) {
         	  break;  // Exit loop if valid acquisition country is entered
           }
           else {
         	  // Error message printed if an invalid country name is entered
         	  System.out.println("Invalid input. Please enter a valid country name.");
           }
        }

        // Validation for the dog's training status
        System.out.println("What is the dog's training status? " + validTrainingStatuses);
        String trainingStatus;
        
        while (true) {
           // Read user input for dog's training status
           trainingStatus = scanner.nextLine();

           // Check if the input is in the list of valid training statuses
           if (validTrainingStatuses.contains(trainingStatus)) {
               // Exit the loop if the input is valid
               break;
           }

           // If the input is not valid, prompt the user to enter a valid training status
           System.out.println("Invalid training status. Please enter a valid status from the "
           		             + "following list: " + validTrainingStatuses);
       }
        
       // Validate reserved input
       System.out.println("Is the dog reserved? Enter 'true' or 'false'");
       boolean reserved;
       // Loop to validate the input for the reserved status
       while (true) {
       	 // Read user input for reserved status
           String input = scanner.nextLine();
            
           // Check if the input is either "true" or "false"
           if (input.equalsIgnoreCase("true") || input.equalsIgnoreCase("false")) {
          	  // Convert the string input to a boolean value
               reserved = Boolean.parseBoolean(input);
               // Exit the loop if the input is valid
               break;
           }
           // If the input is not valid, prompt the user to enter a valid value
           System.out.println("Invalid input. Please enter 'true' or 'false'.");
       }
       
       // Validation for the dog's in service country
       String inServiceCountry;
       while (true) {
          System.out.println("What is the dog's in-service country?");
          inServiceCountry = scanner.nextLine();
          // Check if the dog's inServiceCountry is not empty and contains only letters
          if (!inServiceCountry.isEmpty() && inServiceCountry.matches("[a-zA-Z\\s]+")) {
         	 break;  // Exit loop if the inServiceCountry input is valid
          }
          else {
         	 // Error message printed if the dog's inServiceCountry input is invalid
         	 System.out.println("Invalid input. Please enter a valid country name.");
          }
       }
        
       // Create a new Dog object and add it to the list
       Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, 
      		                 trainingStatus, reserved, inServiceCountry);
       dogList.add(newDog);
       // Success message that prints when a new Dog object is added to the list
       System.out.println("New dog added successfully.");
    }

    // Method to intake a new monkey
    public static void intakeNewMonkey(Scanner scanner) {
   	 // Prompt user for monkey's name and check if it already exists
       System.out.println("What is the monkey's name?");
       String name = scanner.nextLine();
       for (Monkey monkey : monkeyList) {
           if (monkey.getName().equalsIgnoreCase(name)) {
               System.out.println("\n\nThis monkey is already in our system\n\n");
               return;
           }
       }

       // Gather and validate the rest of the information for the new monkey
       System.out.println("What is the monkey's gender?");
       String gender;
       while (true) {
      	  // Read in input for the monkey's gender
           gender = scanner.nextLine();
           // Check if the entered input for gender is either 'male' or 'female'
           if (gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female")) 
         	  // Exit loop if the correct gender input was entered
         	  break;  
           // Error message printed if an incorrect input was entered for the monkey's gender
           System.out.println("Invalid input. Please enter 'male' or 'female'.");
       }

       // Validate the monkey's age input
       String age;
       while (true) {
     	    // Prompt the user for the monkey's age
          System.out.println("What is the monkey's age?");
          age = scanner.nextLine();
          // Check if the age input contains only numbers
          if (age.matches("\\d+")) {
        	    // Convert age input into an integer for comparison
        	    int monkeyAge = Integer.parseInt(age);
        	    // Check to see if the monkey's age input is within a realistic range
        	    if (monkeyAge > 0 && monkeyAge < 50) {
        		    // Exit loop if monkey's age input is valid
        		    break;
        	    }
        	    else {
        		    // Error message if the input for the monkey's age is to low or too high
        		    System.out.println("Invalid age. Please enter a realistic age between 1-50 years");
        	    }
          }
          else {
        	    // Error message if the age input is not a valid integer
        	    System.out.println("Invalid input. Please enter a valid integer for age.");
          }
       }

       // Read in and validate the monkey's weight
       System.out.println("What is the monkey's weight?");
       String weight;
       while (true) {
          // Read in input for the monkey's weight
          weight = scanner.nextLine();
          // Check if input is a valid number
          if (weight.matches("\\d+(\\.\\d+)?")) 
         	 // Exit loop if a valid input was entered for the monkey's weight
         	 break; 
          // Error message printed if an invalid input was entered for the monkey's weight
          System.out.println("Invalid input. Please enter a valid number for weight.");
       }

       // Validation for the monkey's acquisition date
       String acquisitionDate;
       int monkeyAge = 0;
       while(true) {
     	    // Prompt user for the acquisition date
          System.out.println("What is the monkey's acquisition date? Enter in format MM-DD-YYYY.");
          // Convert date from string to an integer for use in isValidAcquisitionDate method
          monkeyAge = Integer.parseInt(age);
          acquisitionDate = scanner.nextLine();
          
          if (RescueAnimal.isValidAcquisitionDate(acquisitionDate, monkeyAge)) {
        	    break;  // Exit loop if the entered acquisition date is valid
          }
          else {
        	  // Error message printed when an invalid monkey acquisition date is entered
        	  System.out.println("Invalid date. Please enter a valid acquisition date that matches "
        	  		              + "the format MM-DD-YYYY and is feasible given the monkey's age.");
          }
       }

       // Validation for the monkey's acquisition country
       String acquisitionCountry;
       while (true) {
     	    // Prompt user for the monkey's acquisition country
          System.out.println("What is the monkey's acquisition country?");
          acquisitionCountry = scanner.nextLine();
          // Check if acquisition country input is not empty and contains only letters
          if (!acquisitionCountry.isEmpty() && acquisitionCountry.matches("[a-zA-Z\\s]+")) {
        	    break;  // Exit loop if valid acquisition country is entered
          }
          else {
        	    // Error message printed if an invalid country name is entered
        	    System.out.println("Invalid input. Please enter a valid country name.");
          }
       }

       // Validate training status input
       System.out.println("What is the monkey's training status? " + validTrainingStatuses);

       // Declare a variable to store the training status
       String trainingStatus;

       // Loop to validate the input for the training status
       while (true) {
          // Read user input
          trainingStatus = scanner.nextLine();
          // Check if the input is in the list of valid training statuses
          if (validTrainingStatuses.contains(trainingStatus)) {
             // Exit the loop if the input is valid
             break;
          }
          // If the input is not valid, prompt the user to enter a valid training status
          System.out.println("Invalid training status. Please enter a valid status from the "
           		             + "following list: " + validTrainingStatuses);
       }

       // Validate reserved input
       System.out.println("Is the monkey reserved? Enter 'true' or 'false'");
       boolean reserved;
       // Loop to validate the input for the reserved status
       while (true) {
          // Read user input
          String input = scanner.nextLine();
          // Check if the input is either "true" or "false"
          if (input.equalsIgnoreCase("true") || input.equalsIgnoreCase("false")) {
             // Convert the string input to a boolean value
             reserved = Boolean.parseBoolean(input);
             // Exit the loop if the input is valid
             break;
          }
            // If the input is not valid, prompt the user to enter a valid value
            System.out.println("Invalid input. Please enter 'true' or 'false'.");
       }
       
       // Validation for the monkey's in service country
       String inServiceCountry;
       while (true) {
          System.out.println("What is the monkey's in-service country?");
          inServiceCountry = scanner.nextLine();
          // Check if the monkey's inServiceCountry is not empty and contains only letters
          if (!inServiceCountry.isEmpty() && inServiceCountry.matches("[a-zA-Z\\s]+")) {
         	 break;  // Exit loop if the inServiceCountry input is valid
          }
          else {
         	 // Error message printed if the monkey's inServiceCountry input is invalid
         	 System.out.println("Invalid input. Please enter a valid country name.");
          }
       }
       
       // Validate species input
       System.out.println("What is the monkey's species? " + validMonkeySpecies);
       String species;
       while (true) {
          species = scanner.nextLine();
          if (validMonkeySpecies.contains(species)) 
         	 // Exit the loop if a valid monkey species is entered
         	 break;
          /* Error message that prints if an invalid species is entered along with a list of valid 
             Monkey species */
          System.out.println("Invalid species. Please enter a valid species from the "
           		               + "following list: " + validMonkeySpecies);
       }

       // Read in and validate the monkey's tail length input
       System.out.println("What is the monkey's tail length?");
       double tailLength;
       while (true) {
          if (scanner.hasNextDouble()) {
             tailLength = scanner.nextDouble();
             // Clear the newline character
             scanner.nextLine(); 
             // Exit the loop if a valid tail length is entered
             break;
          } 
          else {
         	 // Error message if an invalid input is entered for the tail length
             System.out.println("Invalid input. Please enter a valid number for tail length.");
             // Clear the invalid input
             scanner.next(); 
          }
       }

       // Read in and validate the monkey's height input
       System.out.println("What is the monkey's height?");
       double height;
       while (true) {
          if (scanner.hasNextDouble()) {
             height = scanner.nextDouble();
             // Clear the newline character
             scanner.nextLine(); 
             // Exit the loop if a valid height is entered
             break;
          } 
          else {
         	 // Error message printed if an invalid number is entered for the monkey's height
             System.out.println("Invalid input. Please enter a valid number for height.");
             // Clear the invalid input
             scanner.next(); 
          }
       }

       // Read in and validate the monkey's body length
       System.out.println("What is the monkey's body length?");
       double bodyLength;
       while (true) {
          if (scanner.hasNextDouble()) {
             bodyLength = scanner.nextDouble();
             // Clear the newline character
             scanner.nextLine(); 
             // Exit the loop if a valid body length is entered
             break;
          } 
          else {
         	 // Error message printed if an invalid number is entered for the monkey's body length
             System.out.println("Invalid input. Please enter a valid number for body length.");
             // Clear the invalid input
             scanner.next(); 
          }
       }

       // Create a new Monkey object and add it to the list
       Monkey newMonkey = new Monkey(name, gender, age, weight, acquisitionDate, acquisitionCountry,
      		                         trainingStatus, reserved, inServiceCountry, species, 
      		                         tailLength, height, bodyLength);
       monkeyList.add(newMonkey);
       // Success message that prints when a new Monkey object is added to the list
       System.out.println("New monkey added successfully.");
   }
    
   // ReserveAnimal method
   public static void reserveAnimal(Scanner scanner) {
      System.out.println("Enter the animal type. Input either 'dog' or 'monkey': ");
      // Read in input for the animal type
      String animalType = scanner.nextLine().toLowerCase();
      System.out.println("Enter the in-service country: ");
      // Read in input for the in service country
      String inServiceCountry = scanner.nextLine();

      // Boolean to determine if an matching reserve animal was found
      boolean animalFound = false;
        
      // Check if the animal type is valid and perform reservation
      if (animalType.equals("dog") || animalType.equals("monkey")) {
         ArrayList<? extends RescueAnimal> animalList = animalType.equals("dog") ? dogList : monkeyList;
            
            // Iterate through the animal list to find a matching animal
            for (RescueAnimal animal : animalList) {
               if (animal.getInServiceLocation().equalsIgnoreCase(inServiceCountry) && 
               	  !animal.getReserved() && "in service".equalsIgnoreCase(animal.getTrainingStatus())) {
                    animal.setReserved(true);
                    // Capitalizes first letter of animalType and prints message animal was reserved
                    System.out.println(animalType.substring(0, 1).toUpperCase() + 
                  		  animalType.substring(1) + " " + animal.getName() + " has been reserved.");
                    animalFound = true;
                    // Exits out of loop if animal Type was found and reserved
                    break;
               }
            }
      } 
      else {
         // Error message printed if an invalid animal type is entered for reservation
         System.out.println("Invalid animal type. Please enter 'dog' or 'monkey'.");
      }
         // Print message if no matching animal is found
      if (!animalFound) {
         System.out.println("No available " + animalType + " found in " + inServiceCountry + 
            		             " with 'in service' status.");
      }
    }

    // printAnimals method Prints out a list of available animals based on user input
    public static void printAnimals(String listType) {
       switch (listType) {
           case "dog":
         	   // Print a header for the list of all dogs
               System.out.println("List of all dogs:");
               // Iterate over the dog list and print details for each dog
               for (Dog dog : dogList) {
                   System.out.println(dog.getName() + " | " + dog.getTrainingStatus() + " | " 
               + dog.getAcquisitionLocation() + " | " + (dog.getReserved() ? "Reserved" : "Not Reserved"));
               }
               // Exit the switch statement
               break;
           case "monkey":
         	   // Print a header for the list of all monkeys
               System.out.println("List of all monkeys:");
               // Iterate over the monkey list and print details for each available monkey
               for (Monkey monkey : monkeyList) {
                   System.out.println(monkey.getName() + " | " + monkey.getTrainingStatus() + " | " 
               + monkey.getAcquisitionLocation() + " | " + (monkey.getReserved() ? "Reserved" : "Not Reserved"));
               }
               // Exit the switch statement
               break;
           case "available":
         	   // Print a header for the list of all available (in-service and not reserved) animals
               System.out.println("List of all available animals:");
               // Iterate over the dog list and print details for each available dog
               for (Dog dog : dogList) {
                   if ("in service".equalsIgnoreCase(dog.getTrainingStatus()) && !dog.getReserved()) {
                       System.out.println(dog.getName() + " | " + dog.getTrainingStatus() + " | " + 
                                         dog.getAcquisitionLocation() + " | " + 
                     		             (dog.getReserved() ? "Reserved" : "Not Reserved"));
                   }
               }
               // Iterate over the monkey list and print details for each available monkey
               for (Monkey monkey : monkeyList) {
                   if ("in service".equalsIgnoreCase(monkey.getTrainingStatus()) && !monkey.getReserved()) {
                       System.out.println(monkey.getName() + " | " + monkey.getTrainingStatus() + 
                     		               " | " + monkey.getAcquisitionLocation() + " | " + 
                     		              (monkey.getReserved() ? "Reserved" : "Not Reserved"));
                   }
               }
               // Exit the switch statement
               break;
           default:
         	   // Print a message if the list type is invalid
               System.out.println("Invalid list type");
       }
   }
}
