
import java.lang.String;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RescueAnimal {

   // Instance variables to store various attributes of a rescue animal
   private String name;
   private String animalType;
   private String gender;
   private String age;
   private String weight;
   private String acquisitionDate;
   private String acquisitionCountry;
	private String trainingStatus;
   private boolean reserved;
	private String inServiceCountry;


   // Default constructor for the rescue animal class
   public RescueAnimal() {
   }

   // Get the name of the rescue animal
	public String getName() {
		return name;
	}

   // Set the name of the rescue animal
	public void setName(String name) {
		this.name = name;
	}

   // Get the type of rescue animal
	public String getAnimalType() {
		return animalType;
	}

   // Set the type of rescue animal
	public void setAnimalType(String animalType) {
		this.animalType = animalType;
	}

   // Get the gender of the rescue animal
	public String getGender() {
		return gender;
	}

   // Set the gender of the rescue animal
	public void setGender(String gender) {
		this.gender = gender;
	}

   // Get the age of the rescue animal
	public String getAge() {
		return age;
	}

   // Set the age of the rescue animal
	public void setAge(String age) {
		this.age = age;
	}

   // Get the weight of the rescue animal
	public String getWeight() {
		return weight;
	}

   // Set the weight of the rescue animal
	public void setWeight(String weight) {
		this.weight = weight;
	}

   // Get the acquisition date of the rescue animal
	public String getAcquisitionDate() {
		return acquisitionDate;
	}

   // Set the acquisition date of the rescue animal
	public void setAcquisitionDate(String acquisitionDate) {
		this.acquisitionDate = acquisitionDate;
	}

   // Get the acquisition location of the rescue animal
	public String getAcquisitionLocation() {
		return acquisitionCountry;
	}

   // Set the acquisition location of the rescue animal
	public void setAcquisitionLocation(String acquisitionCountry) {
		this.acquisitionCountry = acquisitionCountry;
	}

   // Get the reserved status of the rescue animal
	public boolean getReserved() {
		return reserved;
	}

   // Set the reserved status of the rescue animal
	public void setReserved(boolean reserved) {
		this.reserved = reserved;
	}

   // Get the in service location of the rescue animal
	public String getInServiceLocation() {
		return inServiceCountry;
	}

   // Set the in service location of the rescue animal
	public void setInServiceCountry(String inServiceCountry) {
		this.inServiceCountry = inServiceCountry;
	}

	// Get the training status of the rescue animal
	public String getTrainingStatus() {
		return trainingStatus;
	}

   // Set the training status of the rescue animal
	public void setTrainingStatus(String trainingStatus) {
		this.trainingStatus = trainingStatus;
	}
	
   // Method to validate the rescue animal's acquisition date
   public static boolean isValidAcquisitionDate(String dateStr, int animalAge) {
      SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
      dateFormat.setLenient(false);
   	
      try {
      	// Parse the date string into a Date object
   	   Date acquisitionDate = dateFormat.parse(dateStr);
   	   Date currentDate = new Date();
   		
   	   // Calculate the latest possible acquisition date based on the animal's age
   	   Date latestPossibleDate = new Date(currentDate.getTime() - (long) (animalAge + 1) * 365 * 24 * 60 
   				                                                                    * 60 * 1000L);
   		// Return true if the acquisition date is within the valid range
   	   return !acquisitionDate.after(currentDate) && !acquisitionDate.before(latestPossibleDate);
   	}
   	catch (ParseException e) {
   		// Return false if the date string could not be parsed
   	   return false;
   	}
   } 
}
