# CS 499 Milestone Four - Database Enhancement Summary by John Grudzinski

## Artifact
- **Course:** CS 340 Advanced Programming Concepts
- **Artifact:** Grazioso Salvare MongoDB/Dash Dashboard
- **Category:** Databases

## Original functionality
The original artifact used a Python CRUD module (`aac_crud_v2.py`) to connect a Dash dashboard to MongoDB animal shelter data. The dashboard displayed a data table, rescue-dog filters, a breed distribution chart, and a map.

## Enhancements completed
1. **Credential security**
   - Removed hard-coded default credentials from the enhanced CRUD module.
   - Added support for environment variables: `AAC_USER`, `AAC_PASSWORD`, `AAC_HOST`, `AAC_PORT`, `AAC_DB`, and `AAC_COLLECTION`.

2. **Stronger CRUD validation**
   - Added dictionary validation for create/read/update/delete operations.
   - Rejected empty update and delete queries to reduce the risk of unintended mass updates or deletes.
   - Added validation that update documents use MongoDB update operators such as `$set`, `$inc`, or `$unset`.

3. **Projection support**
   - Added projection support to `read()` so dashboard views request only the fields needed for the table, chart, and map.

4. **Database-side filtering**
   - Added dashboard query builder logic so filters are translated into MongoDB queries instead of filtering a fully loaded DataFrame first.

5. **Aggregation support**
   - Added an `aggregate()` method and an `aggregate_breed_counts()` method to compute breed counts in MongoDB for the pie chart.

6. **Index support**
   - Added `ensure_dashboard_indexes()` to create/reuse indexes for fields used frequently in dashboard filters.

7. **Dashboard robustness**
   - Updated the dashboard to handle empty data, missing coordinates, and invalid row selections more safely.

## Enhanced files
- `aac_crud_v2.py`
- `ProjectTwoDashboard_Enhanced.py`
- `ProjectTwoDashboard_Enhanced.ipynb`
- `config.example.env`

## Original reference files
The original files are included in `Original_Code_Reference` for comparison.

### Please note this project must be run with the SNHU Apporto to run.