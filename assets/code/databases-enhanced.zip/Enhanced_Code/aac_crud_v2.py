"""
Enhanced MongoDB CRUD module Grazioso Salvare dashboard.

CS 499 database enhancements:
- Removes hard-coded credentials by supporting environment variable configuration.
- Adds stronger input validation for create, read, update, delete, and aggregate operations.
- Adds projection support so dashboard views request only the fields they need.
- Adds aggregation support for breed-count reporting.
- Adds index helper methods for common dashboard query fields.
"""

import os
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from bson.objectid import ObjectId
from pymongo import ASCENDING, MongoClient
from pymongo.collection import Collection
from pymongo.database import Database


class AnimalShelter(object):
    """
    CRUD operations for the AAC animals collection in MongoDB.

    Enhanced version supports explicit constructor values but defaults to
    environment variables, which is safer for code that may be published to GitHub.
    """

    # These map the internal config names to the environment variable names.
    # This keeps credentials out of the source code.
    REQUIRED_ENV_VARS = {
        "user": "AAC_USER",
        "password": "AAC_PASSWORD",
        "host": "AAC_HOST",
        "port": "AAC_PORT",
        "db": "AAC_DB",
        "col": "AAC_COLLECTION",
    }

    # These are the fields the dashboard actually needs.
    # Using a field list helps avoid pulling unnecessary data from MongoDB.
    DASHBOARD_FIELDS = [
        "animal_id",
        "animal_type",
        "name",
        "breed",
        "sex_upon_outcome",
        "age_upon_outcome_in_weeks",
        "outcome_type",
        "location_lat",
        "location_long",
    ]

    # These indexes support the fields used most often in dashboard filtering.
    # The compound index helps when several rescue-dog filters are used together.
    DASHBOARD_INDEXES: Sequence[Tuple[Tuple[str, int], ...]] = (
        (("animal_type", ASCENDING),),
        (("breed", ASCENDING),),
        (("sex_upon_outcome", ASCENDING),),
        (("age_upon_outcome_in_weeks", ASCENDING),),
        (
            ("animal_type", ASCENDING),
            ("breed", ASCENDING),
            ("sex_upon_outcome", ASCENDING),
            ("age_upon_outcome_in_weeks", ASCENDING),
        ),
    )

    def __init__(
        self,
        user: Optional[str] = None,
        password: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        db: Optional[str] = None,
        col: Optional[str] = None,
    ):
        """
        Initialize the MongoClient connection to the AAC database.

        Constructor values are supported for local testing, but when values
        are omitted the class reads from environment variables:
        AAC_USER, AAC_PASSWORD, AAC_HOST, AAC_PORT, AAC_DB, and AAC_COLLECTION.
        """
        # Load connection settings from arguments first, then environment variables.
        config = self._load_config(user, password, host, port, db, col)

        # Build the MongoDB connection string from the validated config values.
        uri = f"mongodb://{config['user']}:{config['password']}@{config['host']}:{config['port']}"

        # Create the MongoDB client, select the database, and select the collection.
        self.client: MongoClient = MongoClient(uri)
        self.database: Database = self.client[config["db"]]
        self.collection: Collection = self.database[config["col"]]

    @classmethod
    def _load_config(
        cls,
        user: Optional[str],
        password: Optional[str],
        host: Optional[str],
        port: Optional[int],
        db: Optional[str],
        col: Optional[str],
    ) -> Dict[str, Any]:
        """Build connection configuration from explicit values or environment variables."""
        # Use constructor values when provided, otherwise fall back to environment variables.
        raw_config = {
            "user": user or os.getenv("AAC_USER"),
            "password": password or os.getenv("AAC_PASSWORD"),
            "host": host or os.getenv("AAC_HOST"),
            "port": port or os.getenv("AAC_PORT"),
            "db": db or os.getenv("AAC_DB", "AAC"),
            "col": col or os.getenv("AAC_COLLECTION", "animals"),
        }

        # User, password, host, and port are required for a MongoDB connection.
        missing = [name for name in ("user", "password", "host", "port") if not raw_config.get(name)]
        if missing:
            expected = ", ".join(cls.REQUIRED_ENV_VARS[name] for name in missing)
            raise ValueError(
                "Missing MongoDB configuration. Set these environment variables "
                f"or pass constructor values: {expected}"
            )

        # MongoDB expects the port as an integer, so convert it safely here.
        try:
            raw_config["port"] = int(raw_config["port"])
        except (TypeError, ValueError) as exc:
            raise ValueError("MongoDB port must be a valid integer.") from exc

        return raw_config

    @staticmethod
    def dashboard_projection() -> Dict[str, int]:
        """Return the projection used by the dashboard table, chart, and map."""
        # Build a projection from the dashboard field list.
        projection = {field: 1 for field in AnimalShelter.DASHBOARD_FIELDS}

        # Hide MongoDB's internal _id field because the dashboard does not need to display it.
        projection["_id"] = 0
        return projection

    @staticmethod
    def _validate_dict(value: Any, name: str, allow_empty: bool = False) -> Dict[str, Any]:
        """Validate dictionary-style inputs before sending them to MongoDB."""
        # Allow an empty query only when the caller explicitly says it is okay.
        if value is None:
            if allow_empty:
                return {}
            raise ValueError(f"{name} is required.")

        # MongoDB queries, projections, and update documents should be dictionaries.
        if not isinstance(value, dict):
            raise TypeError(f"{name} must be a dictionary.")

        # For risky operations like update/delete, empty dictionaries are rejected.
        if not allow_empty and not value:
            raise ValueError(f"{name} cannot be empty.")

        return value

    @staticmethod
    def _validate_update_document(update_values: Any) -> Dict[str, Any]:
        """Validate that an update document uses MongoDB update operators."""
        # First confirm the update data is a valid dictionary.
        update_doc = AnimalShelter._validate_dict(update_values, "update_values")

        # Require update operators such as $set so a full document replacement is not done by mistake.
        if not any(str(key).startswith("$") for key in update_doc.keys()):
            raise ValueError("update_values must use MongoDB update operators such as $set, $inc, or $unset.")

        return update_doc

    def create(self, data: Dict[str, Any]) -> bool:
        """Insert a single document into the animals collection."""
        try:
            # Validate the document before trying to insert it.
            document = self._validate_dict(data, "data")

            # Insert one animal record into the collection.
            result = self.collection.insert_one(document)

            # Return True only if MongoDB acknowledged the insert.
            return bool(result.acknowledged)
        except Exception as exc:
            # Keep the dashboard from crashing and show a useful error for debugging.
            print(f"[CREATE ERROR] {exc}")
            return False

    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        limit: Optional[int] = None,
        sort: Optional[Iterable[Tuple[str, int]]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Read documents from MongoDB with optional projection, limit, and sorting.

        Projection support is important for the dashboard because it avoids pulling
        fields that are not used by the table, pie chart, or map.
        """
        try:
            # Allow an empty query here because dashboards sometimes need to show all records.
            filter_query = self._validate_dict(query, "query", allow_empty=True)

            # Projection is optional, but if it is provided it still needs to be a dictionary.
            projection_query = None if projection is None else self._validate_dict(projection, "projection", allow_empty=True)

            # Start the MongoDB find operation.
            cursor = self.collection.find(filter_query, projection_query)

            # Apply sorting if the caller requested it.
            if sort:
                cursor = cursor.sort(list(sort))

            # Apply a limit if one was provided.
            if limit is not None:
                if not isinstance(limit, int) or limit < 0:
                    raise ValueError("limit must be a non-negative integer.")
                cursor = cursor.limit(limit)

            # Convert the cursor into a list so the dashboard can use it easily.
            return list(cursor)
        except Exception as exc:
            # Return an empty list instead of crashing the dashboard.
            print(f"[READ ERROR] {exc}")
            return []

    def read_by_id(self, id_str: str, projection: Optional[Dict[str, int]] = None) -> Optional[Dict[str, Any]]:
        """Find a single document by its MongoDB _id string."""
        try:
            # Convert the string ID into a real MongoDB ObjectId.
            oid = ObjectId(id_str)

            # Projection is optional here too, but it still gets validated when provided.
            projection_query = None if projection is None else self._validate_dict(projection, "projection", allow_empty=True)

            # Return the matching document, or None if it does not exist.
            return self.collection.find_one({"_id": oid}, projection_query)
        except Exception as exc:
            # Invalid ObjectId values or database errors are handled safely.
            print(f"[READ_BY_ID ERROR] {exc}")
            return None

    def update(self, query: Dict[str, Any], update_values: Dict[str, Any]) -> int:
        """Update documents matched by query using a validated MongoDB update document."""
        try:
            # Empty queries are not allowed here because update_many could affect too many records.
            filter_query = self._validate_dict(query, "query")

            # Make sure the update uses operators like $set, $inc, or $unset.
            update_doc = self._validate_update_document(update_values)

            # Run the update and return how many documents were actually modified.
            result = self.collection.update_many(filter_query, update_doc)
            return result.modified_count
        except Exception as exc:
            # Return 0 so the caller knows nothing was updated.
            print(f"[UPDATE ERROR] {exc}")
            return 0

    def delete(self, query: Dict[str, Any]) -> int:
        """
        Delete documents matched by query.

        Empty queries are intentionally rejected to avoid accidental mass deletion.
        """
        try:
            # Empty queries are blocked so delete_many cannot accidentally wipe the collection.
            filter_query = self._validate_dict(query, "query")

            # Delete matching records and return the delete count.
            result = self.collection.delete_many(filter_query)
            return result.deleted_count
        except Exception as exc:
            # Return 0 so the caller knows nothing was deleted.
            print(f"[DELETE ERROR] {exc}")
            return 0

    def aggregate(self, pipeline: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Run a MongoDB aggregation pipeline after validating the input shape."""
        try:
            # Aggregation needs at least one stage.
            if not isinstance(pipeline, list) or not pipeline:
                raise ValueError("pipeline must be a non-empty list.")

            # Each stage should be a non-empty dictionary like {"$match": {...}}.
            if not all(isinstance(stage, dict) and stage for stage in pipeline):
                raise ValueError("each aggregation stage must be a non-empty dictionary.")

            # Run the aggregation and return the result list.
            return list(self.collection.aggregate(pipeline))
        except Exception as exc:
            # Return an empty list so charts can fail gracefully.
            print(f"[AGGREGATE ERROR] {exc}")
            return []

    def aggregate_breed_counts(self, query: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Return dog breed counts for the selected dashboard filter."""
        # Use the selected dashboard filter, or an empty filter if none was provided.
        match_query = self._validate_dict(query, "query", allow_empty=True)

        # This pipeline filters the records, groups dogs by breed, and counts each breed.
        pipeline = [
            {"$match": match_query},
            {"$match": {"animal_type": "Dog", "breed": {"$exists": True, "$nin": [None, ""]}}},
            {"$group": {"_id": "$breed", "count": {"$sum": 1}}},
            {"$sort": {"count": -1, "_id": 1}},
            {"$project": {"_id": 0, "breed": "$_id", "count": 1}},
        ]

        # Reuse the generic aggregate method so validation and error handling stay in one place.
        return self.aggregate(pipeline)

    def ensure_dashboard_indexes(self) -> List[str]:
        """Create indexes used by the dashboard filters and return their names."""
        created = []

        # Loop through each recommended dashboard index and try to create it.
        for index_fields in self.DASHBOARD_INDEXES:
            try:
                # MongoDB will reuse an existing matching index instead of creating duplicates.
                created.append(self.collection.create_index(list(index_fields)))
            except Exception as exc:
                # Index issues should not stop the whole dashboard from running.
                print(f"[INDEX ERROR] {index_fields}: {exc}")

        return created


