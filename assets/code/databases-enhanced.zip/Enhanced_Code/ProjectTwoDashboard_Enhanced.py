"""
Enhanced CS 340 Grazioso Salvare dashboard.

Enhancements:
- Uses aac_crud_v2.AnimalShelter with environment-based MongoDB credentials.
- Pushes dashboard filtering into MongoDB queries instead of filtering a full DataFrame first.
- Uses projection so the dashboard only requests fields it needs.
- Uses MongoDB aggregation for breed-count chart data.
- Adds safer map handling for empty data, missing coordinates, and invalid row selections.
"""

# JupyterDash lets this dashboard run in a notebook style environment if needed.
from jupyter_dash import JupyterDash

import base64
import os

import dash_leaflet as dl
import pandas as pd
import plotly.express as px
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output

# Import the enhanced CRUD module that handles MongoDB access.
from aac_crud_v2 import AnimalShelter


# Rescue criteria from the client requirements.
# Keeping these rules in one dictionary makes the filters easier to update later.
rescue_criteria = {
    "water": {
        "breeds": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"],
        "sex": "Intact Female",
        "min_age": 26,
        "max_age": 156,
    },
    "mountain": {
        "breeds": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"],
        "sex": "Intact Male",
        "min_age": 26,
        "max_age": 156,
    },
    "disaster": {
        "breeds": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"],
        "sex": "Intact Male",
        "min_age": 20,
        "max_age": 300,
    },
}

# Build one sorted list of every rescue breed used across all rescue categories.
# This is useful for filters like "All Eligible Rescue Dogs."
all_rescue_breeds = sorted({breed for criteria in rescue_criteria.values() for breed in criteria["breeds"]})

# Use the projection and field list from the CRUD module so the dashboard and database layer stay consistent.
DASHBOARD_PROJECTION = AnimalShelter.dashboard_projection()
DASHBOARD_COLUMNS = AnimalShelter.DASHBOARD_FIELDS

# Default Austin-area map center used when no marker data is available.
AUSTIN_CENTER = [30.75, -97.48]


# The enhanced CRUD module reads credentials from environment variables by default.
# Required variables: AAC_USER, AAC_PASSWORD, AAC_HOST, AAC_PORT.
# Optional variables: AAC_DB and AAC_COLLECTION.
db = AnimalShelter()

# Index creation is safe to call repeatedly because MongoDB reuses existing matching indexes.
# This supports the fields that the dashboard filters most often.
db.ensure_dashboard_indexes()


def build_rescue_query(rescue_type):
    """Convert the selected dashboard filter into a MongoDB query."""
    # No filter means return everything.
    if rescue_type == "show_all":
        return {}

    # Simple dog-only filter.
    if rescue_type == "all_dogs":
        return {"animal_type": "Dog"}

    # Show all dogs that match at least one of the rescue breed lists.
    if rescue_type == "rescue_all":
        return {"animal_type": "Dog", "breed": {"$in": all_rescue_breeds}}

    # Build a detailed MongoDB query for one specific rescue category.
    if rescue_type in rescue_criteria:
        criteria = rescue_criteria[rescue_type]
        return {
            "animal_type": "Dog",
            "breed": {"$in": criteria["breeds"]},
            "sex_upon_outcome": criteria["sex"],
            "age_upon_outcome_in_weeks": {
                "$gte": criteria["min_age"],
                "$lte": criteria["max_age"],
            },
        }

    # Safe fallback if an unknown filter value is passed in.
    return {}


def build_breed_count_query(filter_type):
    """Build a MongoDB query specifically for breed-count aggregation."""
    # For "show all," the pie chart should still focus on rescue dog breeds.
    if filter_type == "show_all":
        return {"animal_type": "Dog", "breed": {"$in": all_rescue_breeds}}

    # Other filters can reuse the normal rescue query logic.
    return build_rescue_query(filter_type)


def clean_records(records):
    """Convert MongoDB results into JSON-friendly dashboard records."""
    cleaned = []

    # Make sure every row has the same fields the DataTable expects.
    for record in records:
        item = {}
        for field in DASHBOARD_COLUMNS:
            value = record.get(field, "")

            # Replace None values with blank strings so the table displays cleanly.
            item[field] = value if value is not None else ""

        cleaned.append(item)

    return cleaned


def load_dashboard_records(filter_type):
    """Read only the filtered records needed by the dashboard table."""
    # Turn the selected radio button value into a MongoDB query.
    query = build_rescue_query(filter_type)

    # Read filtered records directly from MongoDB instead of loading everything first.
    records = db.read(query=query, projection=DASHBOARD_PROJECTION, sort=[("name", 1)])

    # Clean the records before sending them to Dash.
    return clean_records(records)


def load_logo():
    """Load the logo if it exists; otherwise return None so the dashboard still runs."""
    logo_path = os.path.join("Resources", "Grazioso Salvare Logo.png")

    # If the image is missing, skip it instead of crashing the dashboard.
    if not os.path.exists(logo_path):
        return None

    # Encode the image so it can be displayed directly inside the Dash layout.
    with open(logo_path, "rb") as logo_file:
        return base64.b64encode(logo_file.read()).decode()


def empty_map():
    """Return a safe default map when no valid marker data is available."""
    # This prevents the map callback from crashing when there are no matching records.
    return dl.Map(
        style={"width": "100%", "height": "400px"},
        center=AUSTIN_CENTER,
        zoom=10,
        children=[dl.TileLayer(id="base-layer-id")],
    )


# Load the initial dashboard data before the layout is built.
initial_records = load_dashboard_records("show_all")

# Load the logo once at startup.
encoded_logo = load_logo()

# Create the Dash app.
app = JupyterDash(__name__)

# Build the header dynamically so the dashboard still works if the logo file is missing.
header_children = []
if encoded_logo:
    header_children.append(
        html.Img(
            src=f"data:image/png;base64,{encoded_logo}",
            style={"height": "120px", "marginRight": "1rem"},
            alt="Grazioso Salvare logo",
        )
    )

# Add the dashboard title after the optional logo.
header_children.append(html.H1("John Grudzinski - SNHU CS-340", style={"margin": 0}))

# Main dashboard layout.
app.layout = html.Div([
    # Header section with logo/title.
    html.Div(
        style={"display": "flex", "alignItems": "center", "padding": "1rem"},
        children=header_children,
    ),

    html.Hr(),

    # Radio buttons let the user choose the rescue filter.
    html.Div(
        dcc.RadioItems(
            id="filter-type",
            options=[
                {"label": "Show All Animals", "value": "show_all"},
                {"label": "Show All Dogs", "value": "all_dogs"},
                {"label": "All Eligible Rescue Dogs", "value": "rescue_all"},
                {"label": "Water Rescue Dogs", "value": "water"},
                {"label": "Mountain or Wilderness Rescue Dogs", "value": "mountain"},
                {"label": "Disaster or Individual Tracking Rescue Dogs", "value": "disaster"},
            ],
            value="show_all",
            labelStyle={"display": "inline-block", "marginRight": "1rem"},
            inputStyle={"marginRight": "0.3rem"},
        ),
        style={"textAlign": "center", "margin": "1rem 0"},
    ),

    # Data table displays the records returned from MongoDB.
    dash_table.DataTable(
        id="datatable-id",
        columns=[{"name": c, "id": c} for c in DASHBOARD_COLUMNS],
        data=initial_records,
        page_size=15,
        sort_action="native",
        row_selectable="single",

        # Select the first row by default only when there is data.
        selected_rows=[0] if initial_records else [],

        # Horizontal scrolling helps when there are many columns.
        style_table={"overflowX": "auto"},
    ),

    html.Br(),
    html.Hr(),

    # Chart and map are placed side-by-side.
    html.Div(
        style={"display": "flex", "gap": "1rem"},
        children=[
            html.Div(id="chart-id", style={"flex": 1, "minWidth": "300px"}),
            html.Div(id="map-id", style={"flex": 1, "minWidth": "300px"}),
        ],
    ),
])


@app.callback(
    Output("datatable-id", "data"),
    Input("filter-type", "value"),
)
def filter_table(filter_type):
    """Refresh the table by querying MongoDB with the selected filter."""
    # Every filter change sends a new query to MongoDB.
    return load_dashboard_records(filter_type)


@app.callback(
    Output("datatable-id", "selected_rows"),
    Input("datatable-id", "data"),
)
def reset_selection(table_data):
    """Select the first row after a filter change so the map has a safe default."""
    # If the table has data, select the first row; otherwise select nothing.
    return [0] if table_data else []


@app.callback(
    Output("datatable-id", "style_data_conditional"),
    Input("datatable-id", "selected_columns"),
)
def update_styles(cols):
    """Highlight selected columns in the table."""
    # If no columns are selected, do not apply extra styling.
    return [] if not cols else [{"if": {"column_id": c}, "backgroundColor": "#D2F3FF"} for c in cols]


@app.callback(
    Output("chart-id", "children"),
    Input("filter-type", "value"),
)
def update_pie(filter_type):
    """Build the breed distribution chart from MongoDB aggregation results."""
    # Build a MongoDB query that matches the selected filter.
    query = build_breed_count_query(filter_type)

    # Let MongoDB group and count breeds instead of doing the counting in pandas.
    counts = db.aggregate_breed_counts(query)

    # Show a friendly message instead of an empty/broken chart.
    if not counts:
        return dcc.Markdown("_No breeds to display for this filter._")

    # Convert aggregation results into a DataFrame for Plotly.
    pie_df = pd.DataFrame(counts)

    # Chart titles are customized to match the selected filter.
    titles = {
        "show_all": "Breed distribution for all rescue dog types",
        "all_dogs": "Breed distribution for all dog breeds in the shelter",
        "rescue_all": "Showing distribution of all rescue dog types",
        "water": "Showing distribution of water rescue dogs",
        "mountain": "Showing distribution of mountain/wilderness rescue dogs",
        "disaster": "Showing distribution of disaster/individual tracking dogs",
    }

    # Build the pie chart from the MongoDB aggregation results.
    fig = px.pie(
        pie_df,
        names="breed",
        values="count",
        title=titles.get(filter_type, "Dog Breed Distribution"),
    )

    # Put labels and percentages inside the chart slices.
    fig.update_traces(textposition="inside", textinfo="percent+label")

    # Clean up chart spacing and keep the legend visible.
    fig.update_layout(margin=dict(t=50, b=0, l=0, r=0), showlegend=True)

    return dcc.Graph(figure=fig)


@app.callback(
    Output("map-id", "children"),
    [
        Input("datatable-id", "data"),
        Input("datatable-id", "selected_rows"),
    ],
)
def update_map(table_data, selected_rows):
    """Show map markers for the selected row while safely handling empty data."""
    # Always work with a list so the rest of the code is simpler.
    records = table_data or []

    # If the table is empty, return a default map instead of trying to plot markers.
    if not records:
        return empty_map()

    # Use selected rows if available, otherwise fall back to the first row.
    selected_indices = selected_rows or [0]
    markers = []

    for index in selected_indices:
        # Skip invalid row selections so filter changes do not crash the map.
        if index is None or index < 0 or index >= len(records):
            continue

        row = records[index]

        # This map focuses on dog locations, so non-dog records are skipped.
        if row.get("animal_type") != "Dog":
            continue

        lat = row.get("location_lat")
        lon = row.get("location_long")

        # Skip rows that do not have usable coordinates.
        if pd.isna(lat) or pd.isna(lon) or lat == "" or lon == "":
            continue

        # Add one marker for the selected dog.
        markers.append(
            dl.Marker(
                position=[lat, lon],
                children=[
                    dl.Tooltip(str(row.get("breed", "Unknown breed"))),
                    dl.Popup(html.Div([
                        html.H4(str(row.get("name", "Unknown animal"))),
                        html.P(str(row.get("breed", "Unknown breed"))),
                    ])),
                ],
            )
        )

    # If no valid dog markers could be created, show the safe default map.
    if not markers:
        return empty_map()

    # Center the map on the first valid marker.
    return dl.Map(
        style={"width": "100%", "height": "400px"},
        center=markers[0].position,
        zoom=11,
        children=[dl.TileLayer(id="base-layer-id")] + markers,
    )


# Start the Dash server.
app.run_server(debug=True)

