public class Dog extends RescueAnimal {

   // Dog-specific field.
   private String breed;

   // Constructor for a Dog object with the specified attributes.
   public Dog(String name, String breed, String gender, String age,
         String weight, String acquisitionDate, String acquisitionCountry,
         String trainingStatus, boolean reserved, String inServiceCountry) {
      setName(name);
      setAnimalType("dog");
      setBreed(breed);
      setGender(gender);
      setAge(age);
      setWeight(weight);
      setAcquisitionDate(acquisitionDate);
      setAcquisitionLocation(acquisitionCountry);
      setTrainingStatus(trainingStatus);
      setReserved(reserved);
      setInServiceCountry(inServiceCountry);
   }

   // Accessor Method
   public String getBreed() {
      return breed;
   }

   // Mutator Method
   public void setBreed(String dogBreed) {
      breed = dogBreed;
   }
}
