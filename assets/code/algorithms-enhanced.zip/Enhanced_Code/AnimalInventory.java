import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Centralized collection manager for rescue animals.
 *
 * Milestone Three enhancement.
 * - Uses a HashMap for fast animal lookup by type/name.
 * - Keeps a list for sorted reporting and filtered output.
 * - Moves search, reserve, filter, and sort logic out of Driver.java.
 */
public class AnimalInventory {

    private final Map<String, RescueAnimal> animalsByKey = new HashMap<>();
    private final List<RescueAnimal> allAnimals = new ArrayList<>();

    /**
     * Adds an animal when its unique type/name key does not already exist.
     */
    public boolean addAnimal(RescueAnimal animal) {
        if (animal == null || isBlank(animal.getName()) || isBlank(animal.getAnimalType())) {
            return false;
        }

        String key = makeKey(animal.getAnimalType(), animal.getName());
        if (animalsByKey.containsKey(key)) {
            return false;
        }

        animalsByKey.put(key, animal);
        allAnimals.add(animal);
        return true;
    }

    /**
     * Checks for an existing animal using the HashMap key.
     */
    public boolean exists(String animalType, String name) {
        return animalsByKey.containsKey(makeKey(animalType, name));
    }

    /**
     * Finds an animal directly by type/name instead of scanning the full list.
     */
    public RescueAnimal find(String animalType, String name) {
        return animalsByKey.get(makeKey(animalType, name));
    }

    /**
     * Returns all animals of a requested type, sorted for consistent display.
     */
    public List<RescueAnimal> getAnimalsByType(String animalType) {
        List<RescueAnimal> result = new ArrayList<>();
        for (RescueAnimal animal : allAnimals) {
            if (animal.getAnimalType().equalsIgnoreCase(animalType)) {
                result.add(animal);
            }
        }
        sortAnimals(result);
        return result;
    }

    /**
     * Returns all animals that are in service and not reserved.
     */
    public List<RescueAnimal> getAvailableAnimals() {
        List<RescueAnimal> result = new ArrayList<>();
        for (RescueAnimal animal : allAnimals) {
            if (isAvailable(animal)) {
                result.add(animal);
            }
        }
        sortAnimals(result);
        return result;
    }

    /**
     * Returns available animals that match type and country.
     */
    public List<RescueAnimal> getAvailableAnimals(String animalType, String country) {
        List<RescueAnimal> result = new ArrayList<>();
        for (RescueAnimal animal : allAnimals) {
            boolean typeMatches = animal.getAnimalType().equalsIgnoreCase(animalType);
            boolean countryMatches = animal.getInServiceLocation().equalsIgnoreCase(country);
            if (typeMatches && countryMatches && isAvailable(animal)) {
                result.add(animal);
            }
        }
        sortAnimals(result);
        return result;
    }

    /**
     * Reserves the first matching animal after filtering and sorting candidates.
     */
    public RescueAnimal reserveFirstAvailable(String animalType, String country) {
        List<RescueAnimal> candidates = getAvailableAnimals(animalType, country);
        if (candidates.isEmpty()) {
            return null;
        }

        RescueAnimal selected = candidates.get(0);
        selected.setReserved(true);
        return selected;
    }

    private boolean isAvailable(RescueAnimal animal) {
        return animal != null
                && !animal.getReserved()
                && "in service".equalsIgnoreCase(animal.getTrainingStatus());
    }

    /**
     * Sorts by type, country, and name so output is predictable and easier to
     * review.
     */
    private void sortAnimals(List<RescueAnimal> animals) {
        animals.sort(Comparator
                .comparing((RescueAnimal animal) -> safeLower(animal.getAnimalType()))
                .thenComparing(animal -> safeLower(animal.getInServiceLocation()))
                .thenComparing(animal -> safeLower(animal.getName())));
    }

    private String makeKey(String animalType, String name) {
        return safeLower(animalType) + ":" + safeLower(name);
    }

    private String safeLower(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
