# CS 499 Milestone Three - Algorithms and Data Structures Enhancement by John Grudzinski

## Artifact
- **Artifact name:** Grazioso Salvare Rescue Animal System
- **Origin:** IT 145 Foundation in Application Development
- **Category:** Algorithms and Data Structures


## Major Changes
- Added `AnimalInventory.java` to manage storage, search, filtering, reservation, and sorting.
- Added a `HashMap<String, RescueAnimal>` for fast duplicate checks and direct lookup by animal type/name.
- Kept a list of `RescueAnimal` records for filtering and sorted output.
- Replaced repeated dog/monkey duplicate-search loops with centralized inventory lookup.
- Replaced `ArrayList` membership checks for valid monkey species and training statuses with `LinkedHashSet` collections.
- Added reusable input validation helper methods in `Driver.java`.
- Added sorted output using a `Comparator` in `AnimalInventory`.
- Set `animalType` in the `Dog` and `Monkey` constructors so both can be managed through the shared `RescueAnimal` parent type.
- Updated reservation logic to filter available animals and reserve the first sorted match.

## Files Included
- `Original_Code_Reference/` contains the original submitted Java files.
- `Enhanced_Code/` contains the enhanced Java files for Milestone Three.

## How to Compile and Run
Open a terminal in the `Enhanced_Code` folder and run:

```bash
javac *.java
java Driver
```
