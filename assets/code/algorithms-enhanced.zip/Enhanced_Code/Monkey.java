public class Monkey extends RescueAnimal {

   // Monkey-specific fields.
   private String species;
   private double tailLength;
   private double height;
   private double bodyLength;

   // Constructor for a monkey object with the specified attributes.
   public Monkey(String name, String gender, String age,
         String weight, String acquisitionDate, String acquisitionCountry,
         String trainingStatus, boolean reserved, String inServiceCountry,
         String species, double tailLength, double height, double bodyLength) {
      // Set the inherited properties
      setName(name);
      setAnimalType("monkey");
      setGender(gender);
      setAge(age);
      setWeight(weight);
      setAcquisitionDate(acquisitionDate);
      setAcquisitionLocation(acquisitionCountry);
      setTrainingStatus(trainingStatus);
      setReserved(reserved);
      setInServiceCountry(inServiceCountry);

      // Set the Monkey specific properties
      setSpecies(species);
      setTailLength(tailLength);
      setHeight(height);
      setBodyLength(bodyLength);
   }

   // Get the species of the monkey
   public String getSpecies() {
      return species;
   }

   // Set the species of the monkey
   public void setSpecies(String monkeySpecies) {
      species = monkeySpecies;
   }

   // Get the tail length of the monkey
   public double getTailLength() {
      return tailLength;
   }

   // Set the tail length of the monkey
   public void setTailLength(double tailLength) {
      this.tailLength = tailLength;
   }

   // Get the height of the monkey
   public double getHeight() {
      return height;
   }

   // Set the height of the monkey
   public void setHeight(double height) {
      this.height = height;
   }

   // Get the body length of the monkey
   public double getBodyLength() {
      return bodyLength;
   }

   // Set the body length of the monkey
   public void setBodyLength(double bodyLength) {
      this.bodyLength = bodyLength;
   }
}
