import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Driver {

    // One shared scanner is used throughout the program for console input.
    private static final Scanner scanner = new Scanner(System.in);

    // The enhanced inventory class keeps lookup/filter/sort logic out of the menu
    // driver.
    private static final AnimalInventory inventory = new AnimalInventory();

    // Sets for membership checks like valid
    // species/status checks.
    private static final Set<String> VALID_MONKEY_SPECIES = new LinkedHashSet<>(Arrays.asList(
            "Capuchin",
            "Guenon",
            "Macaque",
            "Marmoset",
            "Squirrel monkey",
            "Tamarin"));

    // Training statuses are stored in a set so validation can quickly check for
    // allowed values.
    private static final Set<String> VALID_TRAINING_STATUSES = new LinkedHashSet<>(Arrays.asList(
            "intake",
            "Phase I",
            "Phase II",
            "Phase III",
            "Phase IV",
            "Phase V",
            "in service"));

    public static void main(String[] args) {
        // Load sample records so the program has animals to search, reserve, and print
        // right away.
        initializeDogList();
        initializeMonkeyList();

        boolean running = true;
        while (running) {
            displayMenu();

            // Normalize the menu choice so uppercase/lowercase input is handled
            // consistently.
            String userInput = scanner.nextLine().trim().toLowerCase();

            switch (userInput) {
                case "1":
                    intakeNewDog(scanner);
                    break;
                case "2":
                    intakeNewMonkey(scanner);
                    break;
                case "3":
                    reserveAnimal(scanner);
                    break;
                case "4":
                    printAnimals("dog");
                    break;
                case "5":
                    printAnimals("monkey");
                    break;
                case "6":
                    printAnimals("available");
                    break;
                case "q":
                    System.out.println("Exiting the application.");
                    running = false;
                    break;
                default:
                    // Any unsupported entry loops the user back to the menu.
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }

        // Close the scanner when the application is finished.
        scanner.close();
    }

    public static void displayMenu() {
        // Simple menu output for the console application.
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }

    public static void initializeDogList() {
        // Sample records make the enhanced search, filter, reserve, and sort behavior
        // easier to test.
        inventory.addAnimal(new Dog("Spot", "German Shepherd", "male", "1", "25.6",
                "05-12-2019", "United States", "intake", false, "United States"));
        inventory.addAnimal(new Dog("Rex", "Great Dane", "male", "3", "35.2",
                "02-03-2020", "United States", "Phase I", false, "United States"));
        inventory.addAnimal(new Dog("Bella", "Chihuahua", "female", "4", "25.6",
                "12-12-2019", "Canada", "in service", false, "Canada"));
    }

    public static void initializeMonkeyList() {
        // These sample monkeys give the program a mix of available and reserved animals
        // to test with.
        inventory.addAnimal(new Monkey("George", "male", "5", "15.5", "06-01-2020",
                "Brazil", "in service", false, "United States", "Capuchin", 20.5, 30.5, 35.0));
        inventory.addAnimal(new Monkey("Lola", "female", "3", "12.3", "04-15-2019",
                "India", "in service", false, "India", "Marmoset", 18.5, 28.2, 30.0));
        inventory.addAnimal(new Monkey("Kong", "male", "10", "30.5", "04-07-1933",
                "United States", "in service", true, "United States", "Capuchin", 30.5, 100.0, 50.0));
    }

    public static void intakeNewDog(Scanner scanner) {
        System.out.println("What is the dog's name?");
        String name = readNonBlank(scanner, "Dog name is required.");

        // The HashMap-backed inventory can check duplicates without manually looping
        // through a dog list.
        if (inventory.exists("dog", name)) {
            System.out.println("\n\nThis dog is already in our system\n\n");
            return;
        }

        // Gather and validate all of the fields needed to create a dog record.
        String breed = readLetters(scanner, "What is the dog's breed?",
                "Invalid input. Please enter a breed that contains only letters.");
        String gender = readGender(scanner, "What is the dog's gender?");
        String age = readIntegerInRange(scanner, "What is the dog's age?", 1, 29,
                "Invalid age. Please enter a realistic age between 1-30 years.");
        String weight = readPositiveDecimal(scanner, "What is the dog's weight?",
                "Invalid input. Please enter a valid number for the dog's weight.");
        String acquisitionDate = readAcquisitionDate(scanner,
                "What is the dog's acquisition date? Enter in format MM-DD-YYYY.", age);
        String acquisitionCountry = readLetters(scanner, "What is the dog's acquisition country?",
                "Invalid input. Please enter a valid country name.");
        String trainingStatus = readFromSet(scanner, "What is the dog's training status? " + VALID_TRAINING_STATUSES,
                VALID_TRAINING_STATUSES, "Invalid training status. Please enter a valid status from the list.");
        boolean reserved = readBoolean(scanner, "Is the dog reserved? Enter 'true' or 'false'");
        String inServiceCountry = readLetters(scanner, "What is the dog's in-service country?",
                "Invalid input. Please enter a valid country name.");

        // Build the Dog object after all input has been validated.
        Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry,
                trainingStatus, reserved, inServiceCountry);

        // Add the dog through AnimalInventory so the list and lookup map stay in sync.
        if (inventory.addAnimal(newDog)) {
            System.out.println("New dog added successfully.");
        } else {
            System.out.println("Dog could not be added.");
        }
    }

    public static void intakeNewMonkey(Scanner scanner) {
        System.out.println("What is the monkey's name?");
        String name = readNonBlank(scanner, "Monkey name is required.");

        // The inventory handles duplicate checking for monkeys the same way it does for
        // dogs.
        if (inventory.exists("monkey", name)) {
            System.out.println("\n\nThis monkey is already in our system\n\n");
            return;
        }

        // Gather shared RescueAnimal fields first.
        String gender = readGender(scanner, "What is the monkey's gender?");
        String age = readIntegerInRange(scanner, "What is the monkey's age?", 1, 49,
                "Invalid age. Please enter a realistic age between 1-50 years.");
        String weight = readPositiveDecimal(scanner, "What is the monkey's weight?",
                "Invalid input. Please enter a valid number for weight.");
        String acquisitionDate = readAcquisitionDate(scanner,
                "What is the monkey's acquisition date? Enter in format MM-DD-YYYY.", age);
        String acquisitionCountry = readLetters(scanner, "What is the monkey's acquisition country?",
                "Invalid input. Please enter a valid country name.");
        String trainingStatus = readFromSet(scanner, "What is the monkey's training status? " + VALID_TRAINING_STATUSES,
                VALID_TRAINING_STATUSES, "Invalid training status. Please enter a valid status from the list.");
        boolean reserved = readBoolean(scanner, "Is the monkey reserved? Enter 'true' or 'false'");
        String inServiceCountry = readLetters(scanner, "What is the monkey's in-service country?",
                "Invalid input. Please enter a valid country name.");

        // Gather monkey-specific fields after the common animal fields.
        String species = readFromSet(scanner, "What is the monkey's species? " + VALID_MONKEY_SPECIES,
                VALID_MONKEY_SPECIES, "Invalid species. Please enter a valid species from the list.");
        double tailLength = Double.parseDouble(readPositiveDecimal(scanner, "What is the monkey's tail length?",
                "Invalid input. Please enter a valid number for tail length."));
        double height = Double.parseDouble(readPositiveDecimal(scanner, "What is the monkey's height?",
                "Invalid input. Please enter a valid number for height."));
        double bodyLength = Double.parseDouble(readPositiveDecimal(scanner, "What is the monkey's body length?",
                "Invalid input. Please enter a valid number for body length."));

        // Build the Monkey object after all fields have passed validation.
        Monkey newMonkey = new Monkey(name, gender, age, weight, acquisitionDate, acquisitionCountry,
                trainingStatus, reserved, inServiceCountry, species, tailLength, height, bodyLength);

        // Add the monkey through AnimalInventory so duplicate checks and storage stay
        // centralized.
        if (inventory.addAnimal(newMonkey)) {
            System.out.println("New monkey added successfully.");
        } else {
            System.out.println("Monkey could not be added.");
        }
    }

    public static void reserveAnimal(Scanner scanner) {
        // Ask which type of animal the user wants to reserve.
        String animalType = readAnimalType(scanner);

        // Ask where the animal needs to be in service.
        String inServiceCountry = readLetters(scanner, "Enter the in-service country:",
                "Invalid input. Please enter a valid country name.");

        // Let AnimalInventory handle the filtering and reservation logic.
        RescueAnimal reservedAnimal = inventory.reserveFirstAvailable(animalType, inServiceCountry);
        if (reservedAnimal == null) {
            System.out.println(
                    "No available " + animalType + " found in " + inServiceCountry + " with 'in service' status.");
            return;
        }

        // Show the animal that was successfully reserved.
        System.out.println(capitalize(animalType) + " " + reservedAnimal.getName() + " has been reserved.");
    }

    public static void printAnimals(String listType) {
        List<RescueAnimal> animals;
        String header;

        // Pick the correct inventory method based on the requested list type.
        switch (listType) {
            case "dog":
                animals = inventory.getAnimalsByType("dog");
                header = "List of all dogs:";
                break;
            case "monkey":
                animals = inventory.getAnimalsByType("monkey");
                header = "List of all monkeys:";
                break;
            case "available":
                animals = inventory.getAvailableAnimals();
                header = "List of all available animals:";
                break;
            default:
                System.out.println("Invalid list type");
                return;
        }

        System.out.println(header);
        if (animals.isEmpty()) {
            System.out.println("No animals found for this list.");
            return;
        }

        // Print each animal in the list using the same summary format.
        for (RescueAnimal animal : animals) {
            printAnimalSummary(animal);
        }
    }

    private static void printAnimalSummary(RescueAnimal animal) {
        String extraDetail = "";

        // Add the most useful type-specific detail to the shared animal summary.
        if (animal instanceof Dog) {
            extraDetail = " | Breed: " + ((Dog) animal).getBreed();
        } else if (animal instanceof Monkey) {
            extraDetail = " | Species: " + ((Monkey) animal).getSpecies();
        }

        // Keep the output compact but still useful for reviewing animal status.
        System.out.println(capitalize(animal.getAnimalType()) + " | "
                + animal.getName() + extraDetail + " | "
                + animal.getTrainingStatus() + " | "
                + animal.getInServiceLocation() + " | "
                + (animal.getReserved() ? "Reserved" : "Not Reserved"));
    }

    private static String readAnimalType(Scanner scanner) {
        while (true) {
            System.out.println("Enter the animal type. Input either 'dog' or 'monkey': ");
            String input = scanner.nextLine().trim().toLowerCase();

            // Only dog and monkey are supported by this artifact.
            if (input.equals("dog") || input.equals("monkey")) {
                return input;
            }

            System.out.println("Invalid animal type. Please enter 'dog' or 'monkey'.");
        }
    }

    private static String readNonBlank(Scanner scanner, String errorMessage) {
        while (true) {
            String input = scanner.nextLine().trim();

            // Return only when the user enters something meaningful.
            if (!input.isEmpty()) {
                return input;
            }

            System.out.println(errorMessage);
        }
    }

    private static String readLetters(Scanner scanner, String prompt, String errorMessage) {
        while (true) {
            System.out.println(prompt);
            String input = scanner.nextLine().trim();

            // This keeps fields like country, gender text, and breed from accepting
            // numbers/symbols.
            if (!input.isEmpty() && input.matches("[a-zA-Z\\s]+")) {
                return input;
            }

            System.out.println(errorMessage);
        }
    }

    private static String readGender(Scanner scanner, String prompt) {
        while (true) {
            System.out.println(prompt);
            String input = scanner.nextLine().trim().toLowerCase();

            // The original project only supports male/female values.
            if (input.equals("male") || input.equals("female")) {
                return input;
            }

            System.out.println("Invalid input. Please enter 'male' or 'female'.");
        }
    }

    private static String readIntegerInRange(Scanner scanner, String prompt, int minInclusive, int maxInclusive,
            String errorMessage) {
        while (true) {
            System.out.println(prompt);
            String input = scanner.nextLine().trim();

            try {
                // Parse the value and make sure it falls inside the expected age range.
                int value = Integer.parseInt(input);
                if (value >= minInclusive && value <= maxInclusive) {
                    return input;
                }
            } catch (NumberFormatException ignored) {
                // Fall through to the shared error message below.
            }

            System.out.println(errorMessage);
        }
    }

    private static String readPositiveDecimal(Scanner scanner, String prompt, String errorMessage) {
        while (true) {
            System.out.println(prompt);
            String input = scanner.nextLine().trim();

            try {
                // Parse the value and require it to be greater than zero.
                double value = Double.parseDouble(input);
                if (value > 0) {
                    return input;
                }
            } catch (NumberFormatException ignored) {
                // Fall through to the shared error message below.
            }

            System.out.println(errorMessage);
        }
    }

    private static String readAcquisitionDate(Scanner scanner, String prompt, String age) {
        // Age was already validated before this method is called, so parsing is safe
        // here.
        int animalAge = Integer.parseInt(age);

        while (true) {
            System.out.println(prompt);
            String date = scanner.nextLine().trim();

            // Reuse RescueAnimal's date validation logic to keep this check consistent.
            if (RescueAnimal.isValidAcquisitionDate(date, animalAge)) {
                return date;
            }

            System.out.println(
                    "Invalid date. Please enter a valid acquisition date in MM-DD-YYYY format that is feasible for the animal's age.");
        }
    }

    private static String readFromSet(Scanner scanner, String prompt, Set<String> validValues, String errorMessage) {
        while (true) {
            System.out.println(prompt);
            String input = scanner.nextLine().trim();

            // Match user input to the official version of the value from the set.
            String canonical = getCanonicalValue(input, validValues);
            if (canonical != null) {
                return canonical;
            }

            System.out.println(errorMessage + " " + validValues);
        }
    }

    private static String getCanonicalValue(String input, Set<String> validValues) {
        // Case-insensitive match so users do not have to type the capitalization
        // perfectly.
        for (String value : validValues) {
            if (value.equalsIgnoreCase(input)) {
                return value;
            }
        }

        return null;
    }

    private static boolean readBoolean(Scanner scanner, String prompt) {
        while (true) {
            System.out.println(prompt);
            String input = scanner.nextLine().trim().toLowerCase();

            // Only accept true or false so reserved status is stored consistently.
            if (input.equals("true") || input.equals("false")) {
                return Boolean.parseBoolean(input);
            }

            System.out.println("Invalid input. Please enter 'true' or 'false'.");
        }
    }

    private static String capitalize(String value) {
        // Guard against null or empty values before using substring.
        if (value == null || value.isEmpty()) {
            return "";
        }

        // Format labels like dog/monkey for cleaner output.
        return value.substring(0, 1).toUpperCase() + value.substring(1).toLowerCase();
    }
}
