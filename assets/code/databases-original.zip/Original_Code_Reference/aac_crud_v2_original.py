# author: John Grudzinski
# aac_crud_v2.py

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ 
    Crud operations for Animal collection in MongoDB
    All of these methods assume the AAC database and "animals" collection already exist
    """
    
    def __init__(
                 self, 
                 user: str = "aacuser", 
                 password: str ="Mongomadness3241", 
                 host: str = "nv-desktop-services.apporto.com", 
                 port: int = 33090,
                 db: str ="AAC", 
                 col: str ="animals"
    ):
        """
        Initialize the MongoClient connection to the AAC database
        and set up the animals collection.
        """
        # Connection variables that are hard wired for the Apporto environment
        # USER = "aacuser"
        # PASS = "Mongomadness3241"
        # HOST = "nv-desktop-services.apporto.com"
        # PORT = 33090
        # DB   = "AAC"
        # COL  = "animals"
        
        # Use an f-string to build the URI
        uri = f"mongodb://{user}:{password}@{host}:{port}"
        # Create the MongoClient using the connection variables
        self.client = MongoClient(uri)
        # Select the database
        self.database = self.client[db]
        # Select the collection
        self.collection = self.database[col]
        
        
    def create(self, data):
        """
        Inserts a single document into the animals collection.
        
        Parameters
        ----------
        data : dict
            A dictionary representing the document to insert.

        Returns
        -------
        bool
            True if the insert operation was acknowledged; otherwise False.
            
        Raises
        -------
        Exception
            If the data parameter is None or empty.
        """
        # Validate that data is actually provided and is a dict.
        if data is not None:
            try:
                # Perform the insert operation
                self.collection.insert_one(data)
                return True
            except Exception as e:
                # Log the error and return False on failure
                print(f"[CREATE ERROR] {e}")
                return False
        else:
            # Raise an exception if no data is present to insert
            raise Exception("Nothing to save, because data parameter is empty")
            
            
    def read(self, query):
        """
        Queries the animals collection for documents matching the filter.
            
        Parameters
        ----------
        query : dict
            A dictionary specifying the find filter; if None, all docs are returned.

        Returns
        -------
        list of dict
            A list of matching documents. Returns an empty list on error.
        """
        # Default to an empty filter if none is provided
        if query is None:
            query = {}
        try:
            # Perform the find operation and convert cursor to a list
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            # Log the error and return an empty list on failure
            print(f"[READ ERROR] {e}")
            return []
        
    def read_by_id(self, id_str):
        """
        Find a single document by its _id string.
        
        Parameters
        ----------
        id_str : str
            The string representation of the MongoDB ObjectId (_id field).

        Returns
        -------
        dict or None
            The matching document as a dictionary, or None if not found
            or if an error occurs (e.g., invalid ObjectId string).
        """
        # Attempt to convert the input string to a valid ObjectId
        try:
            oid = ObjectId(id_str)
            # Query the collection by the _id field
            return self.collection.find_one({"_id": oid})
        except Exception as e:
            # Log the error (invalid id format, connection issues, etc.)
            print(f"[READ_BY_ID ERROR] {e}")
            return None


    def update(self, query, update_values):
        """
        Update one or more documents in the "animals" collection

        Parameters
        ----------
        query : dict
            A dictionary filter that is used to match which documents to update.
            An example: {"animal_id": "TEST001"}.
            
        update_values : dict
            A dictionary specifying the fields and new values to set.
            Has to follow the MongoDB update syntax. As an example:
                {"$set": {"outcome_type": "Foster"}}

        Returns
        -------
        int
            The number of documents matched and modified. If an exception does 
            occur, 0 will be returned.
        """
        if not query or not isinstance(query, dict):
            print("[UPDATE ERROR] Query parameter is either missing or not valid.")
            return 0
        
        try:
            # Use update_many to modify all of the matching documents.
            # update_one can also be used.
            result = self.collection.update_many(query, update_values)
            # Return how many documents have been modified
            return result.modified_count
        except Exception as e:
            print(f"[UPDATE ERROR] {e}")
            return 0
        
        
    def delete(self, query):
        """
        Delete one or more documents from the "animals" collection.

        Parameters
        ----------
        query : dict
            A dictionary filter used to match which documents to delete.
            As an Example: {"animal_id": "TEST001"}

        Returns
        -------
        int
            The number of documents deleted. Returns 0 if an exception occurs
        """
        if not query or not isinstance(query, dict):
            print("[DELETE ERROR] Query parameter is missing or invalid.")
            return 0
        
        try:
            # Use delete_many to remove all matching documents.
            # delete_one can also be used.
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"[DELETE ERROR] {e}")
            return 0
           